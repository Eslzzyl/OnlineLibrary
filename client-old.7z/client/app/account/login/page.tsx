import { useState } from 'react';

export default function Page() {
  const [account, setAccount] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = () => {
    // 在这里处理登录逻辑，可以发送请求到服务器进行验证等
    console.log('Logging in with:', { account, password });
  };

  return (
    <div className='flex flex-col items-center justify-center h-full'>
      <input
        type="text"
        placeholder="输入账号"
        onChange={(e) => setAccount(e.target.value)}
        className="input input-bordered w-full max-w-xs mt-2 mb-2"
      />
      <input
        type="password"
        placeholder="输入密码"
        onChange={(e) => setPassword(e.target.value)}
        className="input input-bordered w-full max-w-xs mt-2 mb-2"
      />
    </div>
  );
}