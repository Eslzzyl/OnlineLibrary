import Link from 'next/link';
import { useState } from 'react';

import Login from '@/app/account/login/page';
import Register from '@/app/account/register/page';

export default function Page() {
  const [view, setView] = useState('login');

  const handleClick = (newView: string) => {
    setView(newView);
  };

  return (
    <div className='flex items-center justify-center w-2/3 h-screen'>
      <div className='card w-2/3 h-2/3 bg-base-100 shadow-xl'>
        <ul className="menu menu-horizontal bg-base-100 rounded-box">
          <li><a onClick={() => handleClick('login')}>登录</a></li>
          <li><a onClick={() => handleClick('register')}>注册</a></li>
        </ul>
        {view === 'login' && <Login />}
        {view === 'register' && <Register />}
      </div>

      <div className='fixed top-0 right-0 w-1/7'>
        <div className="dropdown mr-12 mt-8">
          <div tabIndex={0} role="button" className="btn m-1">
            主题
            <svg width="12px" height="12px" className="h-2 w-2 fill-current opacity-60 inline-block" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 2048 2048"><path d="M1799 349l242 241-1017 1017L7 590l242-241 775 775 775-775z"></path></svg>
          </div>
          <ul tabIndex={0} className="dropdown-content z-[1] p-2 shadow-2xl bg-base-300 rounded-box">
            <li><input type="radio" name="theme-dropdown" className="theme-controller btn btn-sm btn-block btn-ghost justify-start" aria-label="默认" value="default" /></li>
            <li><input type="radio" name="theme-dropdown" className="theme-controller btn btn-sm btn-block btn-ghost justify-start" aria-label="浅色" value="light" /></li>
            <li><input type="radio" name="theme-dropdown" className="theme-controller btn btn-sm btn-block btn-ghost justify-start" aria-label="深色" value="dark" /></li>
          </ul>
        </div>
      </div>
    </div>
  );
}