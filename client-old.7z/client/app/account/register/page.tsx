export default function Page() {
  return <p>Register Page</p>;
}