'use client';

import { useEffect, useRef, useState } from "react";
import GLOBE from "vanta/dist/vanta.globe.min";
import * as THREE from 'three';

import Account from '@/app/account/page';

export default function Home() {
  const [vantaEffect, setVantaEffect] = useState(null)
  const vantaRef = useRef(null)
  useEffect(() => {
    if (!vantaEffect) {
      setVantaEffect(GLOBE({
        el: vantaRef.current,
        THREE: THREE,
        mouseControls: false,
        touchControls: false,
        gyroControls: false,
        minHeight: 200.00,
        minWidth: 200.00,
        scale: 1.00,
        scaleMobile: 1.00,
        color: 0x7d7df5,
        color2: 0xffffff,
        backgroundColor: 0xd7d7d7
      }))
    }
    return () => {
      if (vantaEffect)
        vantaEffect.destroy()
    }
  }, [vantaEffect])

  return (
    <main ref={vantaRef} className="h-screen">
      <Account />
    </main>
  );
}
