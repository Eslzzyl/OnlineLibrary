declare module 'vanta/dist/vanta.clouds.min' {
  const CLOUDS: any;
  export default CLOUDS;
}