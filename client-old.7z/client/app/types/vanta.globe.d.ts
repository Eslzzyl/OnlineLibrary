declare module 'vanta/dist/vanta.globe.min' {
    const GLOBE: any;
    export default GLOBE;
  }